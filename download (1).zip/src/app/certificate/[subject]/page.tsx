// src/app/certificate/[subject]/page.tsx
'use client';

import { Suspense, lazy } from 'react';
import { useParams, notFound, useSearchParams } from 'next/navigation';
import { subjects as allSubjects, classes as allClasses } from '@/lib/data';
import { Skeleton } from '@/components/ui/skeleton';
import { GoBackButton } from '@/components/go-back-button';

const Certificate = lazy(() => import('@/components/certificate').then(module => ({ default: module.Certificate })));

function CertificateLoading() {
  return (
    <div className="flex flex-col gap-8 items-center">
      <div className="w-full max-w-4xl">
        <Card className="w-full max-w-4xl mx-auto overflow-hidden">
          <CardContent className="p-0">
            <div className="p-8 md:p-12 bg-background relative text-center border-4 border-primary aspect-[297/210]">
              <div className="relative z-10 flex flex-col h-full items-center">
                <Skeleton className="h-10 w-40 mb-4" />
                <Skeleton className="h-6 w-72 mb-8" />
                <Skeleton className="h-4 w-64 mb-4" />
                <Skeleton className="h-12 w-96 mb-6" />
                <Skeleton className="h-4 w-80 mb-2" />
                <Skeleton className="h-8 w-64" />
                <div className="flex-grow" />
                <div className="mt-12 flex justify-around items-center w-full">
                  <div className="flex flex-col items-center gap-2">
                    <Skeleton className="h-6 w-24" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                  <Skeleton className="h-20 w-20 rounded-full" />
                  <div className="flex flex-col items-center gap-2">
                    <Skeleton className="h-6 w-24" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
       <div className="mt-8 text-center">
         <Skeleton className="h-12 w-64 rounded-md" />
      </div>
    </div>
  )
}


export default function CertificatePage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const subjectId = params.subject as string;
  const classId = searchParams.get('class');

  if (!subjectId || !classId) {
    notFound();
  }
  
  const classDetails = allClasses.find(c => c.id === classId);
  const subjectDetails = (allSubjects as any)[classId]?.find((s: any) => s.id === subjectId);

  if (!classDetails || !subjectDetails) {
    notFound();
  }

  const studentName = "Student"; // In a real app, get this from user state
  const date = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="flex flex-col gap-8 items-center">
       <div className="w-full max-w-4xl">
         <GoBackButton />
       </div>
      <div className="w-full max-w-4xl">
        <Suspense fallback={<CertificateLoading />}>
         <Certificate 
            studentName={studentName}
            courseName={`${subjectDetails.name} - ${classDetails.name}`}
            date={date}
        />
        </Suspense>
      </div>
    </div>
  );
}
