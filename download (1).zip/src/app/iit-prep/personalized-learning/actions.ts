'use server';

import { personalizedLearningPath, PersonalizedLearningPathInput, PersonalizedLearningPathOutput } from '@/ai/flows/personalized-learning-path';

type PersonalizedPathState = {
  path: PersonalizedLearningPathOutput | null;
  error: string | null;
};

export async function getPersonalizedPath(): Promise<PersonalizedPathState> {
  // In a real app, this data would be fetched from a database for the logged-in user.
  const mockInput: PersonalizedLearningPathInput = {
    studentId: 'user123',
    learningStyle: 'visual',
    quizHistory: [
      { quizId: 'algebra-quiz', topic: 'Algebra', score: 90 },
      { quizId: 'geometry-quiz', topic: 'Geometry', score: 65 },
      { quizId: 'calculus-quiz', topic: 'Calculus', score: 55 },
    ],
    availableLessons: [
      { lessonId: 'Intro-to-Geometry', topic: 'Geometry', description: 'Basics of shapes and angles.' },
      { lessonId: 'Advanced-Calculus', topic: 'Calculus', description: 'Deep dive into derivatives and integrals.' },
      { lessonId: 'Trigonometry-Basics', topic: 'Trigonometry', description: 'Understanding sin, cos, and tan.' },
    ],
    availableQuizzes: [
      { quizId: 'geometry-review-quiz', topic: 'Geometry', description: 'Review quiz for geometric concepts.' },
      { quizId: 'calculus-practice-quiz', topic: 'Calculus', description: 'Practice problems for limits and continuity.' },
      { quizId: 'trigonometry-quiz', topic: 'Trigonometry', description: 'Test your trig knowledge.' },
    ],
  };

  try {
    const result = await personalizedLearningPath(mockInput);
     if (!result || !result.recommendedLessons) {
      throw new Error('AI failed to generate a valid path.');
    }
    return { path: result, error: null };
  } catch (error) {
    console.error('Error calling personalizedLearningPath flow:', error);
    return {
      path: null,
      error: error instanceof Error ? error.message : 'An unknown error occurred.',
    };
  }
}
