'use client';

import { useState } from 'react';
import { getPersonalizedPath } from './actions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Loader2, BookCopy, FileQuestion, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { PersonalizedLearningPathOutput } from '@/ai/flows/personalized-learning-path';
import { GoBackButton } from '@/components/go-back-button';

export default function PersonalizedLearningPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PersonalizedLearningPathOutput | null>(null);
  const { toast } = useToast();

  const handleGenerate = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await getPersonalizedPath();
      if (res.error) {
        throw new Error(res.error);
      }
      setResult(res.path);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: error instanceof Error ? error.message : 'Failed to generate learning path.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <GoBackButton />
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">Personalized Learning Path</h1>
        <p className="text-muted-foreground">
          Discover lessons and quizzes tailored to your needs by our AI.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your AI-Powered Recommendations</CardTitle>
          <CardDescription>
            Click the button below to generate a new learning path based on your recent performance and learning style.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button onClick={handleGenerate} disabled={loading} size="lg">
            {loading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="mr-2 h-4 w-4" />
            )}
            Generate Your Path
          </Button>
        </CardContent>
      </Card>

      {loading && (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      )}

      {result && (
        <div className="grid gap-8 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookCopy className="text-primary"/>
                Recommended Lessons
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {result.recommendedLessons.length > 0 ? (
                result.recommendedLessons.map((lesson, index) => (
                  <div key={index}>
                    <Alert>
                      <AlertTitle className="font-semibold">{lesson.lessonId.replace(/-/g, ' ')}</AlertTitle>
                      <AlertDescription>{lesson.reason}</AlertDescription>
                    </Alert>
                    {index < result.recommendedLessons.length - 1 && <Separator className="my-4"/>}
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No lesson recommendations at this time. Great job!</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileQuestion className="text-primary"/>
                Recommended Quizzes
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
               {result.recommendedQuizzes.length > 0 ? (
                result.recommendedQuizzes.map((quiz, index) => (
                  <div key={index}>
                    <Alert>
                      <AlertTitle className="font-semibold">{quiz.quizId.replace(/-/g, ' ')}</AlertTitle>
                      <AlertDescription>{quiz.reason}</AlertDescription>
                    </Alert>
                     {index < result.recommendedQuizzes.length - 1 && <Separator className="my-4"/>}
                  </div>
                ))
              ) : (
                 <p className="text-muted-foreground">No quiz recommendations at this time. Keep up the good work!</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
