import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, BrainCircuit, FileQuestion } from "lucide-react";
import Link from 'next/link';

export default function IITPrepPage() {
  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">
          IIT Preparation Modules
        </h1>
        <p className="text-muted-foreground">
          Advanced tools and resources to ace the IIT entrance exams.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="flex flex-col">
          <CardHeader>
             <div className="flex items-center gap-3">
              <div className="p-3 rounded-full bg-primary/10 text-primary">
                <BrainCircuit className="w-6 h-6" />
              </div>
              <CardTitle>Personalized Learning Path</CardTitle>
            </div>
            <CardDescription className="pt-2">
              Receive tailored recommendations for lessons and quizzes based on your performance data and learning style.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-grow flex items-end">
            <Button asChild className="w-full">
              <Link href="/iit-prep/personalized-learning">
                Discover Your Path <ArrowRight className="ml-2" />
              </Link>
            </Button>
          </CardContent>
        </Card>
        
        <Card className="flex flex-col">
          <CardHeader>
             <div className="flex items-center gap-3">
              <div className="p-3 rounded-full bg-primary/10 text-primary">
                <FileQuestion className="w-6 h-6" />
              </div>
              <CardTitle>Practice Quizzes</CardTitle>
            </div>
            <CardDescription className="pt-2">
              Test your knowledge with mock tests and practice quizzes designed for IIT-level difficulty.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-grow flex items-end">
            <Button asChild className="w-full">
              <Link href="/iit-prep/quizzes">
                Start Practicing <ArrowRight className="ml-2" />
              </Link>
            </Button>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
