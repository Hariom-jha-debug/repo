'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { subjects as allSubjects } from '@/lib/data';
import Link from 'next/link';
import { ArrowRight, BookCopy, FileQuestion, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { GoBackButton } from '@/components/go-back-button';

const iitSubjects = allSubjects['iit'];

export default function PracticeQuizzesPage() {
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const { toast } = useToast();

  const handleStartQuiz = () => {
    if (!selectedSubject) {
      toast({
        variant: 'destructive',
        title: 'Please select a subject',
        description: 'You must choose a subject to start a quiz.',
      });
      return;
    }
    // In a real app, this would navigate to a quiz page for the selected subject.
    // For now, it can just link to the main subject page for chapters.
    toast({
        title: 'Quiz a coming soon!',
        description: 'For now you can browse the chapters for the selected subject',
    });
  };

  return (
    <div className="flex flex-col gap-8">
      <GoBackButton />
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">Practice Quizzes</h1>
        <p className="text-muted-foreground">
          Select a subject to take a practice quiz.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Choose Your Subject</CardTitle>
          <CardDescription>
            Select one of the core IIT entrance exam subjects to begin.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center gap-6">
          <Select onValueChange={setSelectedSubject}>
            <SelectTrigger className="w-full max-w-xs">
              <SelectValue placeholder="Select a subject..." />
            </SelectTrigger>
            <SelectContent>
              {iitSubjects.map((subject) => (
                <SelectItem key={subject.id} value={subject.id}>
                  {subject.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={handleStartQuiz} size="lg" disabled={!selectedSubject}>
            <Sparkles className="mr-2 h-4 w-4" />
            Start Random Quiz
          </Button>

          {selectedSubject && (
             <Link href={`/subjects/${selectedSubject}?class=iit`}>
                <Button variant="outline">
                    Or View All Chapters <ArrowRight className="ml-2"/>
                </Button>
            </Link>
          )}

        </CardContent>
      </Card>
    </div>
  );
}
