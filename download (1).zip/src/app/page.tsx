
'use client';

import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { classes, subjects as allSubjects } from '@/lib/data';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Home() {
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>('');
  const [tempName, setTempName] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const savedClassId = localStorage.getItem('selectedClass');
    const savedUserName = localStorage.getItem('userName');
    if (savedClassId && savedUserName) {
      setSelectedClass(savedClassId);
      setUserName(savedUserName);
    }
  }, []);

  const handleStart = () => {
    if (!tempName || !selectedClass) {
        toast({
            variant: 'destructive',
            title: 'Name and class are required.',
            description: 'Please enter your name and select a class to continue.',
        });
        return;
    }
    setUserName(tempName);
    localStorage.setItem('selectedClass', selectedClass);
    localStorage.setItem('userName', tempName);
  };
  
  const handleClassChange = (classId: string) => {
    setSelectedClass(classId);
  }

  const handleReset = () => {
    localStorage.removeItem('selectedClass');
    localStorage.removeItem('userName');
    setSelectedClass(null);
    setUserName('');
    setTempName('');
  }

  const subjects = selectedClass ? (allSubjects as any)[selectedClass] || [] : [];

  if (userName && selectedClass) {
      return (
        <div className="flex flex-col gap-8">
           <div>
            <h1 className="text-3xl font-bold tracking-tight font-headline">
              Welcome, {userName}!
            </h1>
            <div className="flex items-center gap-4">
                <p className="text-muted-foreground">
                    You are viewing content for: {classes.find(c => c.id === selectedClass)?.name}. Select a subject to begin.
                </p>
                <Button variant="outline" size="sm" onClick={handleReset}>
                    Change Profile
                </Button>
            </div>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Subjects</CardTitle>
              <CardDescription>
                Choose a subject to view its chapters.
              </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {subjects.map((subject: any) => (
                        <Card key={subject.id} className="flex flex-col">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <subject.icon className="h-6 w-6 text-primary" />
                                    {subject.name}
                                </CardTitle>
                            </CardHeader>
                             <CardContent className="flex-grow flex items-end">
                                <Link href={`/subjects/${subject.id}?class=${selectedClass}`} className="w-full">
                                    <Button className="w-full">
                                        View Chapters <ArrowRight className="ml-2" />
                                    </Button>
                                </Link>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </CardContent>
          </Card>
        </div>
      )
  }

  return (
    <div className="flex flex-col gap-8">
        <div>
            <h1 className="text-3xl font-bold tracking-tight font-headline">
              Welcome to EduVerse
            </h1>
            <p className="text-muted-foreground">
                Please enter your name and select your class to continue.
            </p>
        </div>
        <Card className="max-w-md">
            <CardHeader>
                <CardTitle>Your Details</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
                <Input 
                    placeholder="Enter your name..." 
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                />
                <Select onValueChange={handleClassChange} value={selectedClass ?? ''}>
                    <SelectTrigger><SelectValue placeholder="Select Class..." /></SelectTrigger>
                    <SelectContent>{classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
                 <Button onClick={handleStart}>
                    Start Learning
                </Button>
                <p className="text-xs text-muted-foreground">Your progress will be saved in your browser for this profile.</p>
            </CardContent>
        </Card>
    </div>
  );
}
