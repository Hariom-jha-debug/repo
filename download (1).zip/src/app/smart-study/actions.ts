'use server';

import { smartStudy, SmartStudyInput, SmartStudyOutput } from '@/ai/flows/smart-study-tool';
import { z } from 'zod';

const formSchema = z.object({
  currentLessons: z.string(),
  performanceData: z.string(),
  desiredTopics: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

type SmartStudyState = {
  plan: SmartStudyOutput | null;
  error: string | null;
};

// Helper to parse performance data string
const parsePerformanceData = (data: string): Record<string, number> => {
  const record: Record<string, number> = {};
  const pairs = data.split(',');
  pairs.forEach(pair => {
    const [key, value] = pair.split(':');
    if (key && value) {
      const score = parseInt(value.trim(), 10);
      if (!isNaN(score)) {
        record[key.trim()] = score;
      }
    }
  });
  return record;
};

export async function generateSmartStudyPlan(
  prevState: SmartStudyState,
  formData: FormData
): Promise<SmartStudyState> {
  const validatedFields = formSchema.safeParse({
    currentLessons: formData.get('currentLessons'),
    performanceData: formData.get('performanceData'),
    desiredTopics: formData.get('desiredTopics'),
  });

  if (!validatedFields.success) {
    return {
      plan: null,
      error: 'Invalid form data. Please check your inputs.',
    };
  }

  const { currentLessons, performanceData, desiredTopics } = validatedFields.data;

  const aiInput: SmartStudyInput = {
    studentId: 'user123', // Static for now
    currentLessons: currentLessons.split(',').map(s => s.trim()).filter(s => s),
    performanceData: parsePerformanceData(performanceData),
    desiredTopics: desiredTopics.split(',').map(s => s.trim()).filter(s => s),
  };
  
  if (aiInput.currentLessons.length === 0 || Object.keys(aiInput.performanceData).length === 0 || aiInput.desiredTopics.length === 0) {
    return {
      plan: null,
      error: 'Please fill out all fields.',
    };
  }

  try {
    const result = await smartStudy(aiInput);
    if (!result || !result.studyPlan) {
      throw new Error('AI failed to generate a valid plan.');
    }
    return { plan: result, error: null };
  } catch (error) {
    console.error('Error calling smartStudy flow:', error);
    return {
      plan: null,
      error: error instanceof Error ? error.message : 'An unknown error occurred.',
    };
  }
}
