

'use client';

import { useActionState, useFormStatus } from 'react-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { generateSmartStudyPlan } from './actions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, Wand2, Download, Send, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import React from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Logo } from '@/components/logo';

const formSchema = z.object({
  currentLessons: z.string().min(1, 'Please list at least one current lesson.'),
  performanceData: z.string().min(1, 'Please provide some performance data (e.g., "calculus: 60, vectors: 85").'),
  desiredTopics: z.string().min(1, 'Please list at least one desired topic.'),
});

type FormValues = z.infer<typeof formSchema>;

const initialState = {
  plan: null,
  error: null,
};

function SubmitButton() {
    const { pending } = useFormStatus();
    return (
        <Button type="submit" disabled={pending} className="w-full">
            {pending ? <Loader2 className="animate-spin" /> : <><Wand2 className="mr-2" />Generate Plan</>}
        </Button>
    )
}

export default function SmartStudyPage() {
  const [state, formAction] = useActionState(generateSmartStudyPlan, initialState);
  const [homeworkSubmitted, setHomeworkSubmitted] = React.useState(false);
  const { toast } = useToast();
  const planRef = React.useRef<HTMLDivElement>(null);


  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      currentLessons: 'Vector Algebra, Advanced Probability',
      performanceData: 'Vector Algebra: 85, Thermodynamics: 70, Optics: 60',
      desiredTopics: 'Rotational Motion, Organic Chemistry Mechanisms',
    },
  });
  
  React.useEffect(() => {
    if (state.error) {
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: state.error,
      });
    }
    if (state.plan) {
        setHomeworkSubmitted(false); // Reset homework submission state when a new plan is generated
    }
  }, [state.error, state.plan, toast]);

  const handleDownloadPdf = () => {
    const input = planRef.current;
    if (!input) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not find the plan content to download.',
      });
      return;
    }

    html2canvas(input, {
        scale: 2,
        useCORS: true, 
        backgroundColor: window.getComputedStyle(document.body).backgroundColor,
    }).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      const ratio = canvasWidth / canvasHeight;
      const height = (pdfWidth - 20) / ratio;

      pdf.addImage(imgData, 'PNG', 10, 10, pdfWidth - 20, height);
      pdf.save('EduVerse_Study_Plan.pdf');
    });
  };

  const handleHomeworkSubmit = () => {
    setHomeworkSubmitted(true);
    toast({
        title: "Homework Submitted!",
        description: "Great job on completing your assignments. Keep up the hard work!",
    });
  }

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">Smart Study Tool</h1>
        <p className="text-muted-foreground">
          Let AI create a dynamic study plan tailored just for you, whatever your class.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Your Inputs</CardTitle>
            <CardDescription>Provide your current study details to generate a plan.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form action={formAction} className="space-y-6">
                <FormField
                  control={form.control}
                  name="currentLessons"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Lessons</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Vector Algebra, Thermodynamics" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="performanceData"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Performance Data</FormLabel>
                      <FormControl>
                        <Textarea placeholder="e.g., Topic: Score, Another Topic: Score" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="desiredTopics"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Desired Topics</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Rotational Motion, Organic Chemistry" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <SubmitButton />
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
                <div>
                    <CardTitle>AI-Generated Study Plan</CardTitle>
                    <CardDescription>Your personalized plan will appear here.</CardDescription>
                </div>
                 {state.plan && (
                    <Button onClick={handleDownloadPdf} variant="outline" size="icon">
                        <Download className="h-4 w-4" />
                        <span className="sr-only">Download PDF</span>
                    </Button>
                )}
            </div>
          </CardHeader>
          <CardContent>
             <div ref={planRef} className="p-4 bg-background text-foreground rounded-lg">
                {state.plan && (
                <div className="space-y-4">
                    <div className="mb-6">
                        <Logo/>
                        <h2 className="text-2xl font-bold mt-2 font-headline">Your Personalized Study Plan</h2>
                        <p className="text-sm text-muted-foreground">Generated on: {new Date().toLocaleDateString()}</p>
                    </div>

                    <Alert>
                    <AlertTitle className="font-semibold">Rationale</AlertTitle>
                    <AlertDescription>{state.plan.rationale}</AlertDescription>
                    </Alert>
                    <Accordion type="single" collapsible className="w-full" defaultValue='item-1'>
                        <AccordionItem value="item-1">
                            <AccordionTrigger className="text-lg font-medium">View Study Plan</AccordionTrigger>
                            <AccordionContent>
                            <ul className="list-disc pl-6 space-y-2">
                                {state.plan.studyPlan.map((item, index) => (
                                <li key={index}>{item}</li>
                                ))}
                            </ul>
                            </AccordionContent>
                        </AccordionItem>
                         {state.plan.homework && state.plan.homework.length > 0 && (
                             <AccordionItem value="item-2">
                                <AccordionTrigger className="text-lg font-medium">Homework Assignments</AccordionTrigger>
                                <AccordionContent className="space-y-4">
                                   {state.plan.homework.map((hw, index) => (
                                       <div key={index} className="p-4 rounded-md border">
                                           <h4 className="font-semibold">{hw.topic}</h4>
                                           <ul className="list-decimal pl-5 mt-2 space-y-1 text-muted-foreground">
                                               {hw.questions.map((q, qIndex) => (
                                                   <li key={qIndex}>{q}</li>
                                               ))}
                                           </ul>
                                       </div>
                                   ))}
                                   <Textarea placeholder="Type your answers here... (This is for your reference, submission is just a completion check)" className="mt-4" />
                                </AccordionContent>
                            </AccordionItem>
                         )}
                    </Accordion>
                </div>
                )}
            </div>

            {state.plan && state.plan.homework && state.plan.homework.length > 0 && !homeworkSubmitted && (
                 <div className="mt-6 flex justify-end">
                    <Button onClick={handleHomeworkSubmit}>
                        <Send className="mr-2"/> Submit Homework
                    </Button>
                </div>
            )}

            {homeworkSubmitted && (
                <div className="mt-6 flex items-center justify-center gap-2 text-green-600 font-medium">
                    <CheckCircle />
                    <span>Homework submitted successfully!</span>
                </div>
            )}

            {!state.plan && !state.error && (
              <div className="text-center text-muted-foreground py-16">
                Your plan is waiting. Fill out the form to get started.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
