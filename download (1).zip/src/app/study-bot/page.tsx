'use client';

import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { studyBot, StudyBotInput, StudyBotOutput } from '@/ai/flows/study-bot-flow';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Loader2, Bot, User } from 'lucide-react';
import { cn } from '@/lib/utils';

type Message = {
  role: 'user' | 'model';
  content: string;
};

export default function StudyBotPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const aiInput: StudyBotInput = {
        query: input,
        history: messages,
      };
      const result = await studyBot(aiInput);
      if (result.response) {
        const botMessage: Message = { role: 'model', content: result.response };
        setMessages((prev) => [...prev, botMessage]);
      } else {
        throw new Error('The study bot did not return a response.');
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: error instanceof Error ? error.message : 'Failed to get a response from the study bot.',
      });
       const lastMessage = messages[messages.length -1];
        if(lastMessage.role === 'user'){
            setMessages(messages.slice(0, messages.length -1));
        }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
       <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">
          Study Bot
        </h1>
        <p className="text-muted-foreground">
          Your AI-powered study assistant. Ask me anything!
        </p>
      </div>

      <Card className="flex-1 mt-8 flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot /> AI Chat
          </CardTitle>
          <CardDescription>
            Ask questions about your subjects, and I'll do my best to help.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden">
          <ScrollArea className="h-full pr-4">
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={cn(
                    'flex items-start gap-3',
                    message.role === 'user' ? 'justify-end' : 'justify-start'
                  )}
                >
                  {message.role === 'model' && (
                    <Avatar className="h-9 w-9">
                       <AvatarFallback className="bg-primary text-primary-foreground"><Bot/></AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={cn(
                      'max-w-md rounded-lg p-3',
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    )}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                   {message.role === 'user' && (
                     <Avatar className="h-9 w-9">
                        <AvatarImage src="https://placehold.co/40x40" alt="@student" data-ai-hint="student avatar" />
                        <AvatarFallback>S</AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {loading && (
                 <div className="flex items-start gap-3 justify-start">
                    <Avatar className="h-9 w-9">
                       <AvatarFallback className="bg-primary text-primary-foreground"><Bot/></AvatarFallback>
                    </Avatar>
                     <div className="bg-muted p-3 rounded-lg">
                        <Loader2 className="h-5 w-5 animate-spin"/>
                    </div>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
        <CardFooter className="pt-4">
            <div className="flex w-full items-center space-x-2">
                <Input
                    id="message"
                    placeholder="Type your message..."
                    className="flex-1"
                    autoComplete="off"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && !loading && handleSend()}
                    disabled={loading}
                />
                <Button onClick={handleSend} disabled={loading || !input.trim()}>
                    <Send className="h-4 w-4" />
                    <span className="sr-only">Send</span>
                </Button>
            </div>
        </CardFooter>
      </Card>
    </div>
  );
}
