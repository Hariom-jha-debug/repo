'use client'

import { useParams, useSearchParams, notFound } from 'next/navigation';
import { CurriculumSelector } from '@/components/curriculum-selector';
import { GoBackButton } from '@/components/go-back-button';

export default function SubjectPage() {
    const params = useParams();
    const searchParams = useSearchParams();
    const subjectId = params.subject as string;
    const classId = searchParams.get('class');

    if (!subjectId || !classId) {
        notFound();
    }

    return (
        <div>
            <GoBackButton />
            <CurriculumSelector selectedSubject={subjectId} selectedClass={classId} />
        </div>
    )
}
