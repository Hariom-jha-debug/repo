
'use client';

import { useEffect, useState } from 'react';
import { notFound, useParams } from 'next/navigation';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowRight, FileQuestion, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Terminal } from 'lucide-react';
import { generateLesson, GenerateLessonOutput } from '@/ai/flows/generate-lesson-flow';
import { chapters as allChapters } from '@/lib/data';
import { GoBackButton } from '@/components/go-back-button';

export default function LessonPage() {
  const params = useParams();
  const subject = params.subject as string;
  const chapterId = params.chapter as string;

  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  useEffect(() => {
    const classId = localStorage.getItem('selectedClass');
    if (classId) {
      setSelectedClass(classId);
    }
  }, []);

  const [lesson, setLesson] = useState<GenerateLessonOutput | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const chapterDetails = allChapters[subject as keyof typeof allChapters]?.find(c => c.id === chapterId && c.classId === selectedClass);
  const chaptersForSubject = allChapters[subject as keyof typeof allChapters]?.filter(c => c.classId === selectedClass);
  const currentChapterIndex = chaptersForSubject?.findIndex(c => c.id === chapterId);
  const nextChapter = chaptersForSubject && currentChapterIndex !== -1 ? chaptersForSubject[currentChapterIndex! + 1] : null;

  useEffect(() => {
    if (!chapterDetails) {
      if (selectedClass) { // Only try to fetch if we have a class context
        setLoading(false);
      }
      return;
    }

    const fetchLesson = async () => {
      setLoading(true);
      setError(null);
      try {
        const result = await generateLesson({ topic: chapterDetails.name });
        if (!result) {
          throw new Error('Failed to generate lesson content.');
        }
        setLesson(result);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'An unknown error occurred.');
      } finally {
        setLoading(false);
      }
    };

    fetchLesson();
  }, [chapterDetails, selectedClass]);

  const formattedContent = lesson?.content
    .replace(/&b/g, '') // Remove unwanted symbols
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
    .replace(/\*(.*?)\*/g, '<em>$1</em>') // Italic
    .replace(/\n/g, '<br />'); // New lines

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="text-muted-foreground">Loading your lesson...</p>
      </div>
    );
  }

  if (error) {
     return (
      <Alert variant="destructive">
        <Terminal className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }
  
  if (!chapterDetails) {
    notFound();
  }

  if (!lesson) {
    return (
       <div className="text-center text-muted-foreground py-16">
          No lesson content available for this chapter yet.
       </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <GoBackButton />
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">
          {lesson.title}
        </h1>
        <p className="text-muted-foreground capitalize">
            {subject}
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
                <CardTitle>Lesson Content</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-lg max-w-none text-foreground dark:prose-invert">
              <div dangerouslySetInnerHTML={{ __html: formattedContent || '' }} />
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle>Next Steps</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <p className="text-sm text-muted-foreground">
                Solidify your understanding by attempting the quiz or moving to the next lesson.
              </p>
              <Button asChild size="lg">
                <Link href={`/lessons/${params.subject}/${params.chapter}/quiz`}>
                  <FileQuestion className="mr-2"/>
                  Take Quiz
                </Link>
              </Button>
              {nextChapter ? (
                  <Button asChild variant="outline" size="lg">
                    <Link href={`/lessons/${nextChapter.subjectId}/${nextChapter.id}`}>
                      Next Lesson
                      <ArrowRight className="ml-2"/>
                    </Link>
                  </Button>
              ) : (
                 <Button asChild variant="outline" size="lg">
                    <Link href={`/subjects/${subject}?class=${selectedClass}`}>
                        Back to Chapters
                    </Link>
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
