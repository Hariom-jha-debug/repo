
'use client';

import { useState, useEffect } from 'react';
import { notFound, useParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { CheckCircle, XCircle, Trophy, Loader2, Sparkles, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { chapters as allChapters } from '@/lib/data';
import { generateQuiz, GenerateQuizOutput } from '@/ai/flows/generate-quiz-flow';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import confetti from 'canvas-confetti';
import { useChapterProgress } from '@/hooks/use-chapter-progress';
import { GoBackButton } from '@/components/go-back-button';

type AnswersState = { [key: number]: string };
type QuizQuestion = GenerateQuizOutput['questions'][0];

export default function QuizPage() {
  const params = useParams();
  const router = useRouter();
  const subject = params.subject as string;
  const chapterId = params.chapter as string;

  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  useEffect(() => {
    const classId = localStorage.getItem('selectedClass');
    if (classId) {
      setSelectedClass(classId);
    }
  }, []);

  const chaptersForSubject = selectedClass ? allChapters[subject as keyof typeof allChapters]?.filter(c => c.classId === selectedClass) : [];
  const chapterDetails = chaptersForSubject?.find(c => c.id === chapterId);
  const currentChapterIndex = chaptersForSubject?.findIndex(c => c.id === chapterId);
  const nextChapter = chaptersForSubject && currentChapterIndex !== -1 ? chaptersForSubject[currentChapterIndex! + 1] : null;


  const { toast } = useToast();
  const { setChapterProgress } = useChapterProgress();

  const [quiz, setQuiz] = useState<GenerateQuizOutput | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [answers, setAnswers] = useState<AnswersState>({});
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (!chapterDetails) {
      if (selectedClass) { // Only fetch if we have a class context
        setLoading(false);
      }
      return;
    }

    const fetchQuiz = async () => {
      setLoading(true);
      setError(null);
      try {
        const result = await generateQuiz({ topic: chapterDetails.name });
        if (!result || !result.questions || result.questions.length === 0) {
          throw new Error('Failed to generate a valid quiz.');
        }
        setQuiz(result);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'An unknown error occurred.');
      } finally {
        setLoading(false);
      }
    };

    fetchQuiz();
  }, [chapterDetails, selectedClass]);


  if (!chapterDetails && !loading) {
    notFound();
  }

  const handleValueChange = (questionIndex: number, value: string) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [questionIndex]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quiz) return;
    let currentScore = 0;
    quiz.questions.forEach((q: any, index: number) => {
      if (answers[index]?.trim().toLowerCase() === q.answer.trim().toLowerCase()) {
        currentScore++;
      }
    });
    
    const totalQuestions = quiz.questions.length;
    setScore(currentScore);
    setSubmitted(true);
    
    // Save progress
    if (selectedClass && subject && chapterId) {
      setChapterProgress(`${selectedClass}-${subject}-${chapterId}`, { score: currentScore, total: totalQuestions });
    }


    if (currentScore === totalQuestions) {
      toast({
        title: 'Congratulations! 🎉',
        description: 'You got a perfect score! You earned 5 coins.',
      });
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      // In a real app, you would update the user's coin balance in the database.
    }
  };

  const getResultIcon = (question: QuizQuestion, option: string, questionIndex: number) => {
    if (!submitted) return null;
    const isCorrectAnswer = option.trim().toLowerCase() === question.answer.trim().toLowerCase();
    const isSelectedAnswer = answers[questionIndex]?.trim().toLowerCase() === option.trim().toLowerCase();

    if (isCorrectAnswer) {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    }
    if (isSelectedAnswer && !isCorrectAnswer) {
      return <XCircle className="h-5 w-5 text-red-500" />;
    }
    return null;
  };
  
  const resetQuiz = () => {
    setSubmitted(false);
    setAnswers({});
    setScore(0);
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="text-muted-foreground">Loading your quiz...</p>
      </div>
    );
  }

  if (error) {
     return (
        <Alert variant="destructive">
            <Sparkles className="h-4 w-4" />
            <AlertTitle>Error Generating Quiz</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
        </Alert>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <GoBackButton />
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">
          {chapterDetails?.name} Quiz
        </h1>
        <p className="text-muted-foreground">
          Test your knowledge with this AI-powered quiz.
        </p>
      </div>

      {!submitted ? (
        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Questions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
              {quiz?.questions.map((q, index) => (
                <div key={index}>
                  <p className="font-medium mb-4">{`${index + 1}. ${q.question}`}</p>
                  <RadioGroup onValueChange={(value) => handleValueChange(index, value)} className="space-y-2">
                    {q.options.map((option, optionIndex) => (
                      <div key={optionIndex} className="flex items-center space-x-2">
                        <RadioGroupItem value={option} id={`q${index}-o${optionIndex}`} />
                        <Label htmlFor={`q${index}-o${optionIndex}`}>{option}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
              ))}
              <Button type="submit" size="lg" className="w-full md:w-auto" disabled={Object.keys(answers).length !== quiz?.questions.length}>
                Submit Answers
              </Button>
            </CardContent>
          </Card>
        </form>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Trophy className="text-yellow-500"/> Quiz Results</CardTitle>
            <CardDescription>
              You scored {score} out of {quiz?.questions.length}!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            {quiz?.questions.map((q, index) => (
              <div key={index}>
                <p className="font-medium mb-4">{`${index + 1}. ${q.question}`}</p>
                <div className="space-y-2">
                  {q.options.map((option, optionIndex) => (
                    <div
                      key={optionIndex}
                      className={`flex items-center justify-between p-3 rounded-md border ${
                        option.trim().toLowerCase() === q.answer.trim().toLowerCase() ? 'border-green-500 bg-green-500/10' : 
                        answers[index]?.trim().toLowerCase() === option.trim().toLowerCase() ? 'border-red-500 bg-red-500/10' : ''
                      }`}
                    >
                      <span>{option}</span>
                      {getResultIcon(q, option, index)}
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <div className="flex flex-wrap gap-4">
                <Button onClick={resetQuiz} size="lg">
                    Try Again
                </Button>
                <Button variant="outline" asChild size="lg">
                    <Link href={`/subjects/${subject}?class=${selectedClass}`}>
                        Back to Chapters
                    </Link>
                </Button>
                {nextChapter && (
                  <Button onClick={() => router.push(`/lessons/${nextChapter.subjectId}/${nextChapter.id}`)} size="lg" variant="secondary">
                      Next Chapter <ArrowRight className="ml-2" />
                  </Button>
                )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
