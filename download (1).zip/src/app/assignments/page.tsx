'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { classes, subjects as allSubjects, chapters as allChapters } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Wand2, Upload, CheckCircle, XCircle } from 'lucide-react';
import { generateQuiz, GenerateQuizOutput } from '@/ai/flows/generate-quiz-flow';
import { gradeAssignment, GradeAssignmentInput, GradeAssignmentOutput } from '@/ai/flows/grade-assignment-flow';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { GoBackButton } from '@/components/go-back-button';

export default function AssignmentsPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [generatingQuestions, setGeneratingQuestions] = useState(false);
  
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);

  const [questions, setQuestions] = useState<string[]>([]);
  const [assignmentResult, setAssignmentResult] = useState<GradeAssignmentOutput | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  const subjects = selectedClass ? (allSubjects as any)[selectedClass] || [] : [];
  const chapters = selectedClass && selectedSubject ? (allChapters as any)[selectedSubject]?.filter((c: any) => c.classId === selectedClass) || [] : [];

  const handleGenerateQuestions = async () => {
    if (!selectedChapter) {
      toast({ variant: 'destructive', title: 'Please select a chapter.' });
      return;
    }
    setGeneratingQuestions(true);
    setQuestions([]);
    setAssignmentResult(null);

    try {
        const chapterDetails = chapters.find((c: any) => c.id === selectedChapter);
        if (!chapterDetails) {
            throw new Error('Chapter details not found.');
        }
        const result = await generateQuiz({ topic: chapterDetails.name });
        if (!result || result.questions.length === 0) {
            throw new Error('Could not generate questions.');
        }
        // Get 10 questions
        setQuestions(result.questions.slice(0, 10).map(q => q.question));

    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: error instanceof Error ? error.message : 'Failed to generate questions.' });
    } finally {
      setGeneratingQuestions(false);
    }
  };
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });

  const handleGradeAssignment = async () => {
    if (!imageFile || questions.length === 0) {
      toast({ variant: 'destructive', title: 'Please generate questions and upload an answer sheet.' });
      return;
    }
    setLoading(true);
    setAssignmentResult(null);
    try {
      const imageDataUri = await toBase64(imageFile);
      const input: GradeAssignmentInput = {
        questions,
        answerImageDataUri: imageDataUri,
      };
      const result = await gradeAssignment(input);
      if (!result || !result.grades) {
        throw new Error('AI grader failed to produce a result.');
      }
      setAssignmentResult(result);
    } catch (error) {
        toast({ variant: 'destructive', title: 'Error', description: error instanceof Error ? error.message : 'Failed to grade assignment.' });
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <GoBackButton />
      <div>
        <h1 className="text-3xl font-bold tracking-tight font-headline">Assignments</h1>
        <p className="text-muted-foreground">Generate questions, submit your work, and get AI-powered feedback.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>1. Select Your Assignment</CardTitle>
          <CardDescription>Choose your class, subject, and chapter to generate assignment questions.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-3">
          <Select onValueChange={setSelectedClass} value={selectedClass ?? ''}>
            <SelectTrigger><SelectValue placeholder="Select Class..." /></SelectTrigger>
            <SelectContent>{classes.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select onValueChange={setSelectedSubject} disabled={!selectedClass} value={selectedSubject ?? ''}>
            <SelectTrigger><SelectValue placeholder="Select Subject..." /></SelectTrigger>
            <SelectContent>{subjects.map((s:any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select onValueChange={setSelectedChapter} disabled={!selectedSubject} value={selectedChapter ?? ''}>
            <SelectTrigger><SelectValue placeholder="Select Chapter..." /></SelectTrigger>
            <SelectContent>{chapters.map((c:any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
          </Select>
          <div className="md:col-span-3 text-center">
            <Button onClick={handleGenerateQuestions} disabled={!selectedChapter || generatingQuestions}>
              {generatingQuestions ? <Loader2 className="animate-spin" /> : <Wand2 />}
              {generatingQuestions ? 'Generating...' : 'Generate 10 Questions'}
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {questions.length > 0 && (
        <Card>
            <CardHeader>
                <CardTitle>2. Complete Your Assignment</CardTitle>
                <CardDescription>Write down the answers to the following questions on a piece of paper.</CardDescription>
            </CardHeader>
            <CardContent>
                <ol className="list-decimal list-inside space-y-2">
                    {questions.map((q, i) => <li key={i}>{q}</li>)}
                </ol>
            </CardContent>
        </Card>
      )}

      {questions.length > 0 && (
        <Card>
            <CardHeader>
                <CardTitle>3. Upload and Grade</CardTitle>
                <CardDescription>Take a clear picture of your answer sheet, upload it, and let our AI grade it for you.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center gap-6">
                <Input type="file" accept="image/*" onChange={handleImageChange} className="max-w-sm"/>
                {imagePreview && <img src={imagePreview} alt="Answer sheet preview" className="mt-4 max-w-sm rounded-md border" />}
                 <Button onClick={handleGradeAssignment} disabled={!imageFile || loading}>
                    {loading ? <Loader2 className="animate-spin" /> : <Upload />}
                    {loading ? 'Grading...' : 'Grade My Assignment'}
                </Button>
            </CardContent>
        </Card>
      )}

      {assignmentResult && (
        <Card>
            <CardHeader>
                <CardTitle>Your Graded Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                {assignmentResult.grades.map((grade, index) => (
                    <Alert key={index} variant={grade.isCorrect ? 'default' : 'destructive'}>
                        {grade.isCorrect ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                        <AlertTitle>Question {grade.questionNumber}</AlertTitle>
                        <AlertDescription>
                            <p className="font-semibold">Result: {grade.isCorrect ? 'Correct' : 'Incorrect'}</p>
                            <p>Explanation: {grade.explanation}</p>
                        </AlertDescription>
                    </Alert>
                ))}
            </CardContent>
        </Card>
      )}

    </div>
  );
}
