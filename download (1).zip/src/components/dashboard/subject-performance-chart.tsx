'use client';

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';

interface SubjectPerformanceChartProps {
    data: {
        subject: string;
        performance: number;
        fill: string;
    }[];
}

export function SubjectPerformanceChart({ data }: SubjectPerformanceChartProps) {
    return (
        <ChartContainer config={{}} className="h-64 w-full">
            <ResponsiveContainer>
                <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                    <XAxis dataKey="subject" tickLine={false} axisLine={false} stroke="#888888" fontSize={12} />
                    <YAxis tickLine={false} axisLine={false} stroke="#888888" fontSize={12} />
                    <Tooltip
                      cursor={{ fill: 'hsl(var(--muted))' }}
                      content={<ChartTooltipContent />}
                     />
                    <Bar dataKey="performance" radius={[4, 4, 0, 0]} />
                </BarChart>
            </ResponsiveContainer>
        </ChartContainer>
    );
}
