"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { ArrowRight, Award, Lock, CheckCircle } from 'lucide-react';
import { classes, subjects as allSubjects, chapters as allChapters } from '@/lib/data';
import { useChapterProgress } from '@/hooks/use-chapter-progress';

interface CurriculumSelectorProps {
    selectedSubject: string | null;
    selectedClass: string | null;
}

export function CurriculumSelector({ selectedSubject, selectedClass }: CurriculumSelectorProps) {

  const currentClass = classes.find(c => c.id === selectedClass);
  const subject = selectedClass && selectedSubject ? (allSubjects as any)[selectedClass]?.find((s:any) => s.id === selectedSubject) : null;
  
  const { progress } = useChapterProgress();
  
  const chapters = selectedClass && selectedSubject
    ? (allChapters as any)[selectedSubject]?.filter((c: any) => c.classId === selectedClass) || []
    : [];

  if (!subject) {
    return (
        <div className="text-center text-muted-foreground py-16">
            Please select a class and subject to see the chapters.
        </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
       <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-4">
                <subject.icon className="h-8 w-8 text-primary" />
                <div>
                    <h1 className="text-3xl font-bold tracking-tight font-headline">{subject.name}</h1>
                    <p className="text-muted-foreground">{currentClass?.name}</p>
                </div>
            </div>
            {selectedClass && selectedSubject && (
                 <Button asChild variant="secondary">
                    <Link href={`/certificate/${selectedSubject}?class=${selectedClass}`}>
                        <Award className="mr-2" />
                        Get Certificate
                    </Link>
                </Button>
            )}
        </div>
      {chapters.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {chapters.map((chapter: any, index: number) => {
              const chapterKey = `${selectedClass}-${selectedSubject}-${chapter.id}`;
              const previousChapterKey = index > 0 ? `${selectedClass}-${selectedSubject}-${chapters[index - 1].id}` : null;
              
              const isLocked = index > 0 && !progress[previousChapterKey!];
              const scoreData = progress[chapterKey];

              return (
                <Card key={chapter.id} className={`flex flex-col ${isLocked ? 'bg-muted/50' : ''}`}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{chapter.name}</CardTitle>
                        <CardDescription>{chapter.description}</CardDescription>
                      </div>
                      {isLocked ? (
                        <Lock className="h-5 w-5 text-muted-foreground" />
                      ) : scoreData ? (
                        <div className="flex items-center gap-1 text-sm font-semibold text-green-600">
                          <CheckCircle className="h-5 w-5" />
                          <span>{scoreData.score}/{scoreData.total}</span>
                        </div>
                      ) : null}
                    </div>
                  </CardHeader>
                  <CardContent className="flex-grow flex items-end">
                    <Link href={`/lessons/${chapter.subjectId}/${chapter.id}`} className="w-full" aria-disabled={isLocked} tabIndex={isLocked ? -1 : undefined}>
                      <Button className="w-full" disabled={isLocked}>
                        {isLocked ? 'Locked' : 'Start Lesson'} <ArrowRight className="ml-2" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
        </div>
      )}
    </div>
  );
}
