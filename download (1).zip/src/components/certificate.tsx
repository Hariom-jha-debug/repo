'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Award, Printer, Loader2 } from 'lucide-react';
import React, { useState } from 'react';
import { Logo } from './logo';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { useToast } from '@/hooks/use-toast';

interface CertificateProps {
  studentName: string;
  courseName: string;
  date: string;
}

export function Certificate({ studentName, courseName, date }: CertificateProps) {
    const { toast } = useToast();
    const [isPrinting, setIsPrinting] = useState(false);
    
    const handlePrint = async () => {
        const certificateElement = document.getElementById('certificate');
        if (!certificateElement) {
            toast({
                variant: 'destructive',
                title: 'Error',
                description: 'Could not find certificate content to print.',
            });
            return;
        }
        setIsPrinting(true);

        try {
            // Use html2canvas to render the certificate content to a canvas
            const canvas = await html2canvas(certificateElement, {
                scale: 2, // Higher scale for better quality
                useCORS: true,
                backgroundColor: window.getComputedStyle(document.body).backgroundColor,
            });

            // Use jsPDF to create a PDF from the canvas image
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('l', 'mm', 'a4'); // landscape
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = pdf.internal.pageSize.getHeight();

            const canvasWidth = canvas.width;
            const canvasHeight = canvas.height;
            const ratio = canvasWidth / canvasHeight;
            let newWidth = pdfWidth;
            let newHeight = newWidth / ratio;
            
            if (newHeight > pdfHeight) {
                newHeight = pdfHeight;
                newWidth = newHeight * ratio;
            }

            const x = (pdfWidth - newWidth) / 2;
            const y = (pdfHeight - newHeight) / 2;

            pdf.addImage(imgData, 'PNG', x, y, newWidth, newHeight);
            pdf.save(`${studentName}_${courseName.replace(/ /g, '_')}_Certificate.pdf`);

        } catch(error) {
            console.error("Error generating PDF:", error);
            toast({
                variant: 'destructive',
                title: 'PDF Generation Failed',
                description: 'An error occurred while trying to generate the PDF.',
            });
        } finally {
            setIsPrinting(false);
        }
    };


    return (
        <div className="flex flex-col gap-8 items-center">
            <Card className="w-full max-w-4xl mx-auto overflow-hidden" id="certificate-wrapper">
                <CardContent className="p-0">
                    <div id="certificate" className="p-8 md:p-12 bg-background relative text-center border-4 border-primary aspect-[297/210]">
                         <div className="absolute top-0 left-0 w-full h-full bg-no-repeat bg-center bg-cover opacity-5" style={{backgroundImage: "url('https://www.toptal.com/designers/subtlepatterns/uploads/watercolor.png')"}}></div>

                        <div className="relative z-10 flex flex-col h-full">
                            <div className="flex justify-center mb-4">
                                <Logo />
                            </div>

                            <h2 className="text-2xl font-light text-muted-foreground tracking-widest uppercase">
                                Certificate of Completion
                            </h2>

                            <p className="mt-8 text-lg text-muted-foreground">This certificate is proudly presented to</p>

                            <h1 className="mt-4 text-5xl font-bold text-primary font-headline tracking-tight">
                                {studentName}
                            </h1>

                            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
                                for successfully completing the course
                            </p>
                            <h3 className="mt-2 text-3xl font-semibold text-accent">
                                {courseName}
                            </h3>

                           <div className="flex-grow"></div>

                            <div className="mt-12 flex flex-col md:flex-row justify-around items-center gap-8">
                                <div>
                                    <p className="text-lg font-semibold border-b-2 border-primary pb-1">Date</p>
                                    <p className="mt-2 text-muted-foreground">{date}</p>
                                </div>
                                <div className="text-primary">
                                    <Award size={80} />
                                </div>
                                 <div>
                                    <p className="text-lg font-semibold border-b-2 border-primary pb-1">Signature</p>
                                    <p className="mt-2 text-muted-foreground font-headline text-xl">EduVerse</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
            <div className="mt-8 text-center">
                <Button onClick={handlePrint} size="lg" disabled={isPrinting}>
                    {isPrinting ? <Loader2 className="mr-2 animate-spin" /> : <Printer className="mr-2" />}
                    {isPrinting ? 'Generating PDF...' : 'Print / Download Certificate'}
                </Button>
            </div>
        </div>
    );
}

export default Certificate;
