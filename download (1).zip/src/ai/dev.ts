import { config } from 'dotenv';
config();

import '@/ai/flows/smart-study-tool.ts';
import '@/ai/flows/personalized-learning-path.ts';
import '@/ai/flows/generate-lesson-flow.ts';
import '@/ai/flows/generate-quiz-flow.ts';
import '@/ai/flows/study-bot-flow.ts';
import '@/ai/flows/grade-assignment-flow.ts';