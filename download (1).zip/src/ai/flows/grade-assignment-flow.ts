'use server';

/**
 * @fileOverview Grades a handwritten assignment from an image.
 *
 * - gradeAssignment - A function that takes an image of answers and a list of questions and returns a graded result.
 * - GradeAssignmentInput - The input type for the gradeAssignment function.
 * - GradeAssignmentOutput - The return type for the gradeAssignment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GradeAssignmentInputSchema = z.object({
  questions: z.array(z.string()).describe('The list of questions that were assigned.'),
  answerImageDataUri: z
    .string()
    .describe(
      "A photo of the handwritten answers, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type GradeAssignmentInput = z.infer<typeof GradeAssignmentInputSchema>;

const GradeSchema = z.object({
  questionNumber: z.number().describe('The question number.'),
  isCorrect: z.boolean().describe('Whether the student\'s answer is correct.'),
  explanation: z.string().describe('A brief explanation of why the answer is correct or incorrect.'),
});

const GradeAssignmentOutputSchema = z.object({
  grades: z.array(GradeSchema).describe('An array of graded results for each question.'),
});
export type GradeAssignmentOutput = z.infer<typeof GradeAssignmentOutputSchema>;

export async function gradeAssignment(input: GradeAssignmentInput): Promise<GradeAssignmentOutput> {
  return gradeAssignmentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'gradeAssignmentPrompt',
  input: {schema: GradeAssignmentInputSchema},
  output: {schema: GradeAssignmentOutputSchema},
  prompt: `You are an AI-powered teaching assistant. Your task is to grade a handwritten assignment based on an image provided by the student.

Here are the questions that were assigned:
{{#each questions}}
{{@index + 1}}. {{{this}}}
{{/each}}

Here is the image of the student's handwritten answers:
{{media url=answerImageDataUri}}

Please analyze the image, interpret the handwritten answers for each question, and determine if they are correct. Provide a boolean result and a brief explanation for each question. Be lenient with handwriting interpretation but strict with the correctness of the answer. If you cannot decipher an answer, mark it as incorrect.

Provide the output in JSON format.`,
});

const gradeAssignmentFlow = ai.defineFlow(
  {
    name: 'gradeAssignmentFlow',
    inputSchema: GradeAssignmentInputSchema,
    outputSchema: GradeAssignmentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
