// Implemented personalized learning path flow using Genkit to analyze user quiz performance and recommend tailored lessons and quizzes.

'use server';

/**
 * @fileOverview AI-powered personalized learning path recommendation.
 *
 * - personalizedLearningPath - A function that recommends lessons and practice quizzes based on user performance.
 * - PersonalizedLearningPathInput - The input type for the personalizedLearningPath function.
 * - PersonalizedLearningPathOutput - The return type for the personalizedLearningPath function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PersonalizedLearningPathInputSchema = z.object({
  studentId: z.string().describe('Unique identifier for the student.'),
  quizHistory: z.array(
    z.object({
      quizId: z.string().describe('Unique identifier for the quiz.'),
      topic: z.string().describe('The topic covered by the quiz.'),
      score: z.number().describe('The student\'s score on the quiz (0-100).'),
    })
  ).describe('History of quizzes taken by the student.'),
  learningStyle: z.string().describe('The identified learning style of the student (e.g., visual, auditory, kinesthetic).'),
  availableLessons: z.array(
    z.object({
      lessonId: z.string().describe('Unique identifier for the lesson.'),
      topic: z.string().describe('The topic covered by the lesson.'),
      description: z.string().describe('A brief description of the lesson content.'),
    })
  ).describe('List of available lessons.'),
  availableQuizzes: z.array(
    z.object({
      quizId: z.string().describe('Unique identifier for the quiz.'),
      topic: z.string().describe('The topic covered by the quiz.'),
      description: z.string().describe('A brief description of the quiz content.'),
    })
  ).describe('List of available quizzes.'),
});

export type PersonalizedLearningPathInput = z.infer<typeof PersonalizedLearningPathInputSchema>;

const PersonalizedLearningPathOutputSchema = z.object({
  recommendedLessons: z.array(
    z.object({
      lessonId: z.string().describe('Unique identifier of the recommended lesson.'),
      reason: z.string().describe('Reason for recommending this lesson.'),
    })
  ).describe('List of lessons recommended for the student.'),
  recommendedQuizzes: z.array(
    z.object({
      quizId: z.string().describe('Unique identifier of the recommended quiz.'),
      reason: z.string().describe('Reason for recommending this quiz.'),
    })
  ).describe('List of quizzes recommended for the student.'),
});

export type PersonalizedLearningPathOutput = z.infer<typeof PersonalizedLearningPathOutputSchema>;

export async function personalizedLearningPath(input: PersonalizedLearningPathInput): Promise<PersonalizedLearningPathOutput> {
  return personalizedLearningPathFlow(input);
}

const prompt = ai.definePrompt({
  name: 'personalizedLearningPathPrompt',
  input: {schema: PersonalizedLearningPathInputSchema},
  output: {schema: PersonalizedLearningPathOutputSchema},
  prompt: `You are an AI-powered learning path generator. Analyze the student's quiz history, learning style, and available lessons/quizzes to recommend the most relevant educational content.

Student ID: {{{studentId}}}
Learning Style: {{{learningStyle}}}

Quiz History:
{{#each quizHistory}}
- Quiz ID: {{{quizId}}}, Topic: {{{topic}}}, Score: {{{score}}}
{{/each}}

Available Lessons:
{{#each availableLessons}}
- Lesson ID: {{{lessonId}}}, Topic: {{{topic}}}, Description: {{{description}}}
{{/each}}

Available Quizzes:
{{#each availableQuizzes}}
- Quiz ID: {{{quizId}}}, Topic: {{{topic}}}, Description: {{{description}}}
{{/each}}

Based on this information, recommend lessons and quizzes that will help the student improve their understanding and address their weaknesses. Provide a clear reason for each recommendation.

Output in JSON format:
{
  "recommendedLessons": [
    {
      "lessonId": "lesson123",
      "reason": "This lesson covers a topic where the student has shown weakness."
    }
  ],
  "recommendedQuizzes": [
    {
      "quizId": "quiz456",
      "reason": "This quiz reinforces concepts from a lesson the student struggled with."
    }
  ]
}
`,
});

const personalizedLearningPathFlow = ai.defineFlow(
  {
    name: 'personalizedLearningPathFlow',
    inputSchema: PersonalizedLearningPathInputSchema,
    outputSchema: PersonalizedLearningPathOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
