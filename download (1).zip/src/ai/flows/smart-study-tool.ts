'use server';

/**
 * @fileOverview Smart Study Tool for IIT aspirants. This flow curates a
 * personalized study plan by dynamically incorporating lessons based on
 * the user's performance and includes homework assignments.
 *
 * - smartStudy - A function that curates a personalized study plan with homework.
 * - SmartStudyInput - The input type for the smartStudy function.
 * - SmartStudyOutput - The return type for the smartStudy function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SmartStudyInputSchema = z.object({
  studentId: z.string().describe('Unique identifier for the student.'),
  currentLessons: z
    .array(z.string())
    .describe('List of lessons the student is currently studying.'),
  performanceData: z
    .record(z.number())
    .describe(
      'A record of student performance on various topics (topic name as key, score as value).'
    ),
  desiredTopics: z
    .array(z.string())
    .describe('List of topics the student wishes to study.'),
});
export type SmartStudyInput = z.infer<typeof SmartStudyInputSchema>;

const HomeworkAssignmentSchema = z.object({
  topic: z.string().describe('The topic of the homework.'),
  questions: z.array(z.string()).describe('A list of 2-3 questions for the homework assignment.'),
});

const SmartStudyOutputSchema = z.object({
  studyPlan: z
    .array(z.string())
    .describe(
      'A curated list of lesson names and topics recommended for the student, adapting to the student performance and desired topics.'
    ),
  rationale: z
    .string()
    .describe(
      'Explanation of why the recommended lessons and topics were chosen.'
    ),
  homework: z.array(HomeworkAssignmentSchema).describe('A list of homework assignments based on the study plan.'),
});
export type SmartStudyOutput = z.infer<typeof SmartStudyOutputSchema>;

export async function smartStudy(input: SmartStudyInput): Promise<SmartStudyOutput> {
  return smartStudyFlow(input);
}

const smartStudyPrompt = ai.definePrompt({
  name: 'smartStudyPrompt',
  input: {schema: z.object({
    studentId: z.string(),
    currentLessons: z.array(z.string()),
    performanceData: z.string(), // Changed to string
    desiredTopics: z.array(z.string()),
  })},
  output: {schema: SmartStudyOutputSchema},
  prompt: `You are an AI-powered study plan curator for students of all classes. Your goal is to create an efficient and personalized study plan based on the student's current progress, performance data, and desired topics.

  Student ID: {{{studentId}}}
  Current Lessons: {{#if currentLessons}}{{#each currentLessons}}- {{{this}}}{{/each}}{{else}}None{{/if}}
  Performance Data (Topic: Score):
{{{performanceData}}}
  Desired Topics: {{#if desiredTopics}}{{#each desiredTopics}}- {{{this}}}{{/each}}{{else}}None{{/if}}

  Analyze the student's performance data and current lessons. Identify areas where the student is struggling or excelling. Incorporate lessons that address the student's weaknesses and build upon their strengths. Also take into consideration the students desired topics when generating a response.
  The study plan should include a curated list of lesson names and topics, along with a rationale explaining why each lesson/topic was chosen. Lessons should only appear once in the study plan.

  In addition to the study plan, create a 'homework' section. For each major topic in the study plan, create one homework assignment with 2-3 challenging questions that test the student's understanding. These questions should be relevant to the student's class level.
  `,
});

const smartStudyFlow = ai.defineFlow(
  {
    name: 'smartStudyFlow',
    inputSchema: SmartStudyInputSchema,
    outputSchema: SmartStudyOutputSchema,
  },
  async input => {
    // Format performance data into a simple string to avoid complex Handlebars logic.
    const performanceDataString = Object.entries(input.performanceData)
      .map(([topic, score]) => `- ${topic}: ${score}`)
      .join('\n');

    const promptInput = {
      ...input,
      performanceData: performanceDataString,
    };

    const {output} = await smartStudyPrompt(promptInput);
    return output!;
  }
);
