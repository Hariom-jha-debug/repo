'use server';

/**
 * @fileOverview An AI-powered study bot that answers student questions.
 *
 * - studyBot - A function that provides answers to student queries.
 * - StudyBotInput - The input type for the studyBot function.
 * - StudyBotOutput - The return type for the studyBot function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const StudyBotInputSchema = z.object({
  query: z.string().describe('The student\'s question.'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.string(),
  })).optional().describe('The conversation history.'),
});
export type StudyBotInput = z.infer<typeof StudyBotInputSchema>;

const StudyBotOutputSchema = z.object({
  response: z.string().describe('The AI\'s response to the student\'s question.'),
});
export type StudyBotOutput = z.infer<typeof StudyBotOutputSchema>;


export async function studyBot(input: StudyBotInput): Promise<StudyBotOutput> {
  return studyBotFlow(input);
}

const studyBotFlow = ai.defineFlow(
  {
    name: 'studyBotFlow',
    inputSchema: StudyBotInputSchema,
    outputSchema: StudyBotOutputSchema,
  },
  async (input) => {
    const { history, query } = input;

    const { text } = await ai.generate({
      prompt: query,
      history: history?.map(h => ({ role: h.role, content: [{ text: h.content }] })) || [],
      system: 'You are a friendly and helpful study bot for students from Class 6 to 12 and IIT aspirants. Explain concepts clearly and concisely. If you don\'t know the answer, say so.'
    });

    return { response: text };
  }
);
