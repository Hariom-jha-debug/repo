'use server';

/**
 * @fileOverview Generates lesson content using an AI model.
 *
 * - generateLesson - A function that creates lesson content for a specific topic.
 * - GenerateLessonInput - The input type for the generateLesson function.
 * - GenerateLessonOutput - The return type for the generateLesson function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateLessonInputSchema = z.object({
  topic: z.string().describe('The topic for which to generate the lesson content.'),
});
export type GenerateLessonInput = z.infer<typeof GenerateLessonInputSchema>;

const GenerateLessonOutputSchema = z.object({
    title: z.string().describe('The title of the lesson.'),
    content: z.string().describe('The detailed content of the lesson, formatted in Markdown.'),
});
export type GenerateLessonOutput = z.infer<typeof GenerateLessonOutputSchema>;

export async function generateLesson(input: GenerateLessonInput): Promise<GenerateLessonOutput> {
  return generateLessonFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateLessonPrompt',
  input: {schema: GenerateLessonInputSchema},
  output: {schema: GenerateLessonOutputSchema},
  prompt: `You are an expert educator. Generate a very detailed and comprehensive lesson about "{{{topic}}}".

The lesson should include:
1. A clear title.
2. A detailed and extensive content body of at least 500 words, written in Markdown format. The content should be well-structured with headings, subheadings, bullet points, and bold text for key terms. It should be easy to understand for a high school student, providing in-depth explanations, examples, and context.

Provide the output in JSON format.`,
});

const generateLessonFlow = ai.defineFlow(
  {
    name: 'generateLessonFlow',
    inputSchema: GenerateLessonInputSchema,
    outputSchema: GenerateLessonOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
