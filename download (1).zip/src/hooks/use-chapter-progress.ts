
'use client';

import { useState, useEffect, useCallback } from 'react';

const PROGRESS_STORAGE_KEY = 'eduverse-chapter-progress';

type ChapterScore = {
  score: number;
  total: number;
};

type ProgressState = {
  [chapterKey: string]: ChapterScore;
};

export function useChapterProgress() {
  const [progress, setProgress] = useState<ProgressState>({});

  useEffect(() => {
    try {
      const savedProgress = localStorage.getItem(PROGRESS_STORAGE_KEY);
      if (savedProgress) {
        setProgress(JSON.parse(savedProgress));
      }
    } catch (error) {
      console.error('Failed to load chapter progress from localStorage', error);
    }
  }, []);

  const setChapterProgress = useCallback((chapterKey: string, scoreData: ChapterScore) => {
    setProgress((prevProgress) => {
      const newProgress = { ...prevProgress, [chapterKey]: scoreData };
      try {
        localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(newProgress));
      } catch (error) {
        console.error('Failed to save chapter progress to localStorage', error);
      }
      return newProgress;
    });
  }, []);

  return { progress, setChapterProgress };
}
